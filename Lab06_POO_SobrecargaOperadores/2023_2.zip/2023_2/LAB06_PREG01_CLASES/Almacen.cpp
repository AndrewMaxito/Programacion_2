
/* 
 * File:   Almacen.cpp
 * Author: andre
 * 
 * Created on 22 de mayo de 2024, 19:07
 */

#include "Almacen.h"

Almacen::Almacen() {
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}

